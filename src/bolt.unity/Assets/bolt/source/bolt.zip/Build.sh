#!/usr/bin/bash
mono ./FAKE/tools/Fake.exe Build.fsx