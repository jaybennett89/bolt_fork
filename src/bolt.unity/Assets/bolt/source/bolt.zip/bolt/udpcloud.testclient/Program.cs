﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UdpKit;

namespace udpcloud.testclient {
  class Program {
    static void Main (string[] args) {
      //UdpLog.SetWriter((l, m) => Console.WriteLine(m));

      //UdpSocket s = UdpSocket.Create(new UdpPlatformManaged());
      //UdpEndPoint master = new UdpEndPoint(new UdpIPv4Address(137, 117, 212, 153), 40000);
      //s.StartCloud(master, UdpEndPoint.Any);

      //while (true) {
      //  UdpEvent evnt;

      //  while (s.Poll(out evnt)) {
      //    switch (evnt.EventType) {
      //      case UdpEventType.SocketStarted:
      //        if (s.LocalEndPoint.Address.Byte0 < 255) {
      //          s.Connect(new UdpEndPoint(new UdpIPv4Address(10, 0, 255, 255), 0));
      //        }
      //        break;
      //    }
      //  }

      //  Thread.Sleep(1);
      //}
    }
  }
}
