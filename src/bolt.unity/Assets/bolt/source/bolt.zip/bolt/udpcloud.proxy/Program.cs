﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace udpcloud.proxy {
  class Program {
    static void Main (string[] args) {
      CloudMaster cloud = new CloudMaster(new IPEndPoint(IPAddress.Any, 40000));
      cloud.Run();
    }
  }
}
