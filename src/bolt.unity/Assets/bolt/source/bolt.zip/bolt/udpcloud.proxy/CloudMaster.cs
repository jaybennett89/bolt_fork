﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  public class CloudMaster {
    CloudSocket cloudSocket;
    List<CloudProxy> cloudProxies;
    ConcurrentBag<IPAddress> cloudAddresses;
    ConcurrentDictionary<IPAddress, CloudConnection> cloudAddressLookup;
    ConcurrentDictionary<IPEndPoint, CloudConnection> proxyEndPointLookup;
    ConcurrentDictionary<IPEndPoint, CloudConnection> masterEndPointLookup;

    public CloudMaster (IPEndPoint endpoint) {
      cloudSocket = new CloudSocket(endpoint);
      cloudAddressLookup = new ConcurrentDictionary<IPAddress, CloudConnection>();
      proxyEndPointLookup = new ConcurrentDictionary<IPEndPoint, CloudConnection>();
      masterEndPointLookup = new ConcurrentDictionary<IPEndPoint, CloudConnection>();

      InitializeIPAddressBag();
      InitializeCloudProxies(endpoint.Address, endpoint.Port + 1, 1);
    }

    public void Run () {
      // do this in the background
      Task.Run(() => cloudSocket.AsyncReceive());

      // main loop
      while (true) {
        SocketAsyncEventArgs args;

        if (cloudSocket.ReceivedData.TryDequeue(out args, 10000)) {
          HandleConnectRequest(args);

          // recycle argument object
          cloudSocket.PutArgs(args);
        }

        GC.Collect();
      }
    }

    public void RegisterProxyEndPoint (CloudConnection connection) {
      if (proxyEndPointLookup.TryAdd(connection.ProxyEndPoint, connection) == false) {
        throw new NotImplementedException();
      }
    }

    public bool FindConnectionByCloudAddress (IPAddress address, out CloudConnection connection) {
      return cloudAddressLookup.TryGetValue(address, out connection);
    }

    public bool FindConnectionByProxyEndPoint (IPEndPoint endpoint, out CloudConnection connection) {
      return proxyEndPointLookup.TryGetValue(endpoint, out connection);
    }

    void InitializeCloudProxies (IPAddress address, int startPort, int count) {
      cloudProxies = new List<CloudProxy>();

      for (int i = 0; i < count; ++i) {
        cloudProxies.Add(new CloudProxy(this, new IPEndPoint(address, startPort + i)));
      }
    }

    void InitializeIPAddressBag () {
      cloudAddresses = new ConcurrentBag<IPAddress>();

      for (int a = 0; a < 1; ++a) {
        for (int b = 0; b < 256; ++b) {
          for (int c = 0; c < 256; ++c) {
            cloudAddresses.Add(new IPAddress(new byte[] { 10, (byte) a, (byte) b, (byte) c }));
          }
        }
      }
    }

    void SendConnectToken (CloudConnection connection) {
      // write token into buffer
      SocketAsyncEventArgs sendArgs = cloudSocket.GetArgs();
      CloudPacket writer = new CloudPacket(sendArgs);
      writer.WriteByte(HeaderBytes.TOKEN_GRANTED);
      writer.WriteAddress(connection.CloudAddress);
      writer.WriteGuid(connection.CloudToken);
      writer.WriteUShort(connection.CloudProxy.Port);

      sendArgs.SetBuffer(sendArgs.Buffer, sendArgs.Offset, writer.Count);

      // send to connection
      cloudSocket.AsyncSend(connection, sendArgs);

      // log
      Console.WriteLine("sending connection token to {0}", connection.MasterEndPoint);
    }

    void HandleConnectRequest (SocketAsyncEventArgs args) {
      IPEndPoint endpoint = (IPEndPoint) args.RemoteEndPoint;
      CloudConnection connection = null;

      if (masterEndPointLookup.TryGetValue(endpoint, out connection) == false) {
        IPAddress cloudAddress = null;

        if (cloudAddresses.TryTake(out cloudAddress) == false) {
          throw new NotImplementedException();
          return;
        }

        connection = new CloudConnection();
        connection.CloudToken = Guid.NewGuid();
        connection.CloudAddress = cloudAddress;
        connection.MasterEndPoint = endpoint;

        int index = 0;
        int count = int.MaxValue;

        for (int i = 0; i < cloudProxies.Count; ++i) {
          if (cloudProxies[i].Count < count) {
            count = cloudProxies.Count;
            index = i;
          }
        }

        connection.CloudProxy = cloudProxies[index];

        if (masterEndPointLookup.TryAdd(endpoint, connection) == false) {
          throw new NotImplementedException();
          return;
        }

        if (cloudAddressLookup.TryAdd(connection.CloudAddress, connection) == false) {
          throw new NotImplementedException();
          return;
        }

        if (cloudProxies[index].AddConnection(connection) == false) {
          throw new NotImplementedException();
          return;
        }

        Console.WriteLine("Accepted connection from {0}", endpoint);
      }

      SendConnectToken(connection);
    }
  }
}
