﻿using System.Collections.Concurrent;
using System.Threading;

namespace udpcloud.proxy {
  public class CloudQueue<T> {
    AutoResetEvent queueEvent;
    ConcurrentQueue<T> queue;

    public AutoResetEvent Event {
      get { return queueEvent; }
    }

    public CloudQueue () {
      queue = new ConcurrentQueue<T>();
      queueEvent = new AutoResetEvent(false);
    }

    public bool Wait (int timeout) {
      return queueEvent.WaitOne(timeout);
    }

    public bool TryDequeue (out T item) {
      return queue.TryDequeue(out item);
    }

    public bool TryDequeue (out T item, int timeout) {
      if (Wait(timeout)) {
        return TryDequeue(out item);
      }

      item = default(T);
      return false;
    }

    public void Enqueue (T item) {
      queue.Enqueue(item);
      queueEvent.Set();
    }
  }
}
