﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  public class CloudConnection {
    public Guid CloudToken;
    public CloudProxy CloudProxy;
    public IPAddress CloudAddress;
    
    public IPEndPoint ProxyEndPoint;
    public IPEndPoint MasterEndPoint;
  }
}
