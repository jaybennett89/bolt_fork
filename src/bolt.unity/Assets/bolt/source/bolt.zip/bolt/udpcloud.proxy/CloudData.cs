﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  struct CloudData {
    public IPEndPoint EndPoint;
    public byte[] Data;
    public int Offset;
    public int Length;
  }
}
