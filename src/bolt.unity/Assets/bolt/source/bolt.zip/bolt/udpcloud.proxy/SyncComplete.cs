﻿namespace udpcloud.proxy {
  public sealed class SyncComplete {
    public static readonly SyncComplete Instance = new SyncComplete();

    SyncComplete () {

    }
  }
}
