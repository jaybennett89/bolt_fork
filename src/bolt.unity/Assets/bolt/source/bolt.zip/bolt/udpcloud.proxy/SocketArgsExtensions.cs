﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  public static class SocketArgsExtensions {

    public static CloudSocket GetCloudSocket (this SocketAsyncEventArgs args) {
      return (CloudSocket) args.UserToken;
    }
  }
}
