﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  struct SendOp {
    public CloudConnection Connection;
    public SocketAsyncEventArgs Args;
  }

  public class CloudSocket {

    Socket socket;
    SocketArgsPool argsPool;

    int sendOpsPending;

    CloudQueue<SendOp> sendOps;
    CloudQueue<SocketAsyncEventArgs> receivedData;

    public CloudQueue<SocketAsyncEventArgs> ReceivedData {
      get { return receivedData; }
    }

    public ushort Port {
      get { return (ushort) ((IPEndPoint) socket.LocalEndPoint).Port; }
    }

    public CloudSocket (IPEndPoint endpoint) {
      socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
      socket.Blocking = false;
      socket.Bind(endpoint);

      sendOps = new CloudQueue<SendOp>();
      argsPool = new SocketArgsPool();
      receivedData = new CloudQueue<SocketAsyncEventArgs>();
    }

    public SocketAsyncEventArgs GetArgs () {
      return argsPool.Get();
    }

    public void PutArgs (SocketAsyncEventArgs args) {
      argsPool.Put(args);
    }

    public void AsyncReceive () {
      while (true) {
        SocketAsyncEventArgs args = argsPool.Get();
        args.UserToken = this;
        args.RemoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
        args.Completed += ReceiveCompleted;

        if (socket.ReceiveFromAsync(args)) {
          return;
        } else {
          ReceiveCompleted(SyncComplete.Instance, args);
        }
      }
    }

    public void AsyncSend (CloudConnection connection, SocketAsyncEventArgs args) {
      sendOps.Enqueue(new SendOp {
        Args = args,
        Connection = connection
      });

      if (Interlocked.Increment(ref sendOpsPending) == 1) {
        SendNext();
      }
    }

    void SendNext () {
      SendOp op;

      if (sendOps.TryDequeue(out op) == false) {
        //TODO: Handle error
        return;
      }

      op.Args.Completed += SendCompleted;
      op.Args.RemoteEndPoint = op.Connection.MasterEndPoint;

      socket.SendToAsync(op.Args);
    }

    void SendCompleted (object sender, SocketAsyncEventArgs args) {
      if ((sender is SyncComplete) == false) {
        if (Interlocked.Decrement(ref sendOpsPending) > 0) {
          SendNext();
        }
      }
    }

    void ReceiveCompleted (object sender, SocketAsyncEventArgs args) {
      receivedData.Enqueue(args);

      if ((sender is SyncComplete) == false) {
        AsyncReceive();
      }
    }
  }
}
