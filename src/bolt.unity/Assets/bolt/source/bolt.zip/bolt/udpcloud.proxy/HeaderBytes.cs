﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  public static class HeaderBytes {
    public const byte VIRTUAL_PACKET = 0;
    public const byte REQUEST_TOKEN = 1;
    public const byte TOKEN_GRANTED = 3;
    public const byte CONNECT_REQUEST = 5;
    public const byte CONNECT_GRANTED = 7;
  }
}
