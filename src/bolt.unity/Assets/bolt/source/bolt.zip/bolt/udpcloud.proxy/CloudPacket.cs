﻿using System;
using System.Net;
using System.Net.Sockets;

namespace udpcloud.proxy {

  public struct CloudPacket {
    public int Count;
    public int Offset;
    public byte[] Data;
    public SocketAsyncEventArgs Args;

    public CloudPacket (SocketAsyncEventArgs args) {
      Data = args.Buffer;
      Offset = args.Offset;
      Count = 0;
      Args = args;
    }

    public void WriteByteArray (byte[] array) {
      WriteByteArray(array, array.Length);
    }

    public void WriteByteArray (byte[] array, int arrayLength) {
      WriteByteArray(array, 0, arrayLength);
    }

    public void WriteByteArray (byte[] array, int arrayOffset, int arrayLength) {
      Array.Copy(array, arrayOffset, Data, Offset, arrayLength);

      Count += arrayLength;
      Offset += arrayLength;
    }

    public byte[] ReadByteArray (int arrayLength) {
      byte[] array = new byte[arrayLength];
      Array.Copy(Data, Offset, array, 0, arrayLength);

      Count += arrayLength;
      Offset += arrayLength;

      return array;
    }

    public void WriteByte (byte value) {
      Data[Offset] = value;

      Count += 1;
      Offset += 1;
    }

    public byte ReadByte () {
      byte value = Data[Offset];

      Count += 1;
      Offset += 1;

      return value;
    }

    public void WriteUShort (ushort value) {
      WriteByteArray(BitConverter.GetBytes(value), 2);
    }

    public int ReadUShort () {
      return BitConverter.ToUInt16(ReadByteArray(2), 0);
    }

    public void WriteInt (int value) {
      WriteByteArray(BitConverter.GetBytes(value), 4);
    }

    public int ReadInt () {
      return BitConverter.ToInt32(ReadByteArray(4), 0);
    }

    public void WriteGuid (Guid guid) {
      WriteByteArray(guid.ToByteArray(), 16);
    }

    public Guid ReadGuid () {
      return new Guid(ReadByteArray(16));
    }

    public void WriteAddress (IPAddress address) {
      WriteByteArray(address.GetAddressBytes(), 4);
    }

    public IPAddress ReadAddress () {
      return new IPAddress(ReadByteArray(4));
    }

    public void Commit () {
      Args.SetBuffer(Args.Buffer, Args.Offset, Count);
    }
  }
}
