﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  public class CloudProxy {
    int count;
    Thread thread;
    CloudMaster master;
    CloudSocket socket;
    ConcurrentDictionary<Guid, CloudConnection> connections;

    public int Count {
      get { return count; }
    }

    public ushort Port {
      get { return socket.Port; }
    }

    public CloudProxy (CloudMaster cloudMaster, IPEndPoint endpoint) {
      master = cloudMaster;
      socket = new CloudSocket(endpoint);
      connections = new ConcurrentDictionary<Guid, CloudConnection>();

      // spin up thread
      thread = new Thread(Run);
      thread.IsBackground = true;
      thread.Name = "Udp Cloud Thread";
      thread.Start();
    }

    public void Run () {
      Task.Run(() => socket.AsyncReceive());

      while (true) {
        SocketAsyncEventArgs args;

        if (socket.ReceivedData.TryDequeue(out args, 10000)) {
          CloudPacket reader = new CloudPacket(args);

          switch (reader.ReadByte()) {
            case HeaderBytes.CONNECT_REQUEST: HandleConnectRequest(reader); break;
            case HeaderBytes.VIRTUAL_PACKET: HandleVirtualPacket(reader); break;
          }

          socket.PutArgs(args);
        }
      }
    }

    void HandleConnectRequest (CloudPacket reader) {
      Guid token = reader.ReadGuid();
      CloudConnection connection = null;

      if (connections.TryGetValue(token, out connection)) {
        CloudPacket writer = new CloudPacket(socket.GetArgs());
        writer.WriteByte(HeaderBytes.CONNECT_GRANTED);
        writer.Commit();

        if (connection.ProxyEndPoint == null) {
          // set proxy endpoint
          connection.ProxyEndPoint = (IPEndPoint) reader.Args.RemoteEndPoint;

          // register connection
          master.RegisterProxyEndPoint(connection);
        }

        // send reply back
        socket.AsyncSend(connection, writer.Args);

      } else {
        //TODO: Handle Error
      }
    }

    void HandleVirtualPacket (CloudPacket reader) {
      CloudConnection source;

      if (master.FindConnectionByProxyEndPoint((IPEndPoint) reader.Args.RemoteEndPoint, out source)) {
        IPAddress sourceAddress = source.CloudAddress;
        IPAddress targetAddress = reader.ReadAddress();

        CloudConnection target;

        if (master.FindConnectionByCloudAddress(targetAddress, out target)) {

          CloudPacket writer = new CloudPacket(target.CloudProxy.socket.GetArgs());
          writer.WriteByte(HeaderBytes.VIRTUAL_PACKET);
          writer.WriteAddress(sourceAddress);
          writer.WriteByteArray(reader.Args.Buffer, 5, reader.Args.BytesTransferred - 5);

          // be on your way! :)
          target.CloudProxy.socket.AsyncSend(target, writer.Args);

        } else {
          throw new NotImplementedException();
        }
      } else {
        throw new NotImplementedException();
      }
    }

    void ForwardPacket (CloudConnection target, CloudPacket reader) {

      SocketAsyncEventArgs args = socket.GetArgs();


    }

    public bool AddConnection (CloudConnection connection) {
      if (connections.TryAdd(connection.CloudToken, connection)) {
        Interlocked.Increment(ref count);
        return true;
      } else {
        //TODO: Log Error
        return false;
      }
    }
  }
}
