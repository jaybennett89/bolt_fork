﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace udpcloud.proxy {
  public class SocketArgsPool {
    public SocketAsyncEventArgs Get () {
      SocketAsyncEventArgs args = new SocketAsyncEventArgs();
      args.SetBuffer(new byte[1024], 0, 1024);
      return args;
    }

    public void Put (SocketAsyncEventArgs args) {

    }
  }
}
