/** Automatically generated file. DO NOT MODIFY */
package fholm.udpkit.nativeandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}