﻿using System;
using UnityEngine;

public enum BoltRandomFunction {
  PerlinNoise,
  SystemRandom
}

[Serializable]
public sealed class BoltConfig {

  public GameObject serverObject;
  public GameObject clientObject;

  public int framesPerSecond = 60;

  public int clientSendRate;
  public int clientDejitterDelay;
  public int clientDejitterDelayMin;
  public int clientDejitterDelayMax;

  public int serverSendRate;
  public int serverDejitterDelay;
  public int serverDejitterDelayMin;
  public int serverDejitterDelayMax;
  public int serverConnectionLimit;

  public int commandDejitterDelay;
  public int commandQueueSize;

  public int commandDelayAllowed;
  public int commandRedundancy;
  public float commandPingMultiplier;

  public float simulatedLoss;
  public int simulatedPingMean;
  public int simulatedPingJitter; 
  public BoltRandomFunction simulatedRandomFunction = BoltRandomFunction.PerlinNoise;

  public BoltConfig () {
    // sendrates of server/client
    serverSendRate = 3;
    clientSendRate = 2;

    // interpolation delay on client is based on server rate
    clientDejitterDelay = serverSendRate;
    clientDejitterDelayMin = clientDejitterDelay - serverSendRate;
    clientDejitterDelayMax = clientDejitterDelay + serverSendRate;

    // interpolation delay on server is based on client rate
    serverDejitterDelay = clientSendRate;
    serverDejitterDelayMin = serverDejitterDelay - clientSendRate;
    serverDejitterDelayMax = serverDejitterDelay + clientSendRate;

    // max clients connected to the server
    serverConnectionLimit = BoltCore.MAX_CONNECTIONS;

    // commands config
    commandRedundancy = 6;
    commandPingMultiplier = 1.25f;
    commandDejitterDelay = 3;
    commandDelayAllowed = clientDejitterDelay * 2;
    commandQueueSize = 60;
  }

  internal BoltConfig Clone () {
    return (BoltConfig) MemberwiseClone();
  }
}
