﻿/// <summary>
/// Empty marker interface all events must implement
/// </summary>
public interface IBoltEvent {

}
