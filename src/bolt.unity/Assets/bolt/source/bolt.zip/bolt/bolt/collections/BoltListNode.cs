﻿public interface IBoltListNode {
  object prev { get; set; }
  object next { get; set; }
  object list { get; set; }
}
