﻿using UnityEngine;

public class BoltConfigAsset : ScriptableObject {
  public BoltConfig config = new BoltConfig();
}
