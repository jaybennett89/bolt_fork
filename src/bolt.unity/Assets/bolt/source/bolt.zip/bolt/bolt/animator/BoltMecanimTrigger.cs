﻿using System;

internal struct BoltMecanimTrigger {
  public ulong value;
  public Action callback;
}