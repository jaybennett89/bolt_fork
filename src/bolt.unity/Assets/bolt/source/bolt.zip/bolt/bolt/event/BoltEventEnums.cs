﻿using System;

public enum BoltEventDeliveryMode {
  Unreliable,
  UnreliableSynced,
  Reliable,
}
