﻿using UnityEngine;

/// <summary>
/// Asset which contains a Bolt map
/// </summary>
public class BoltMapAsset : ScriptableObject {

  [SerializeField]
  internal int _id = -1;

  [SerializeField]
  internal string _scenePath;

  [SerializeField]
  internal string _sceneName;

  [SerializeField]
  internal GameObject _userToken;

  [SerializeField]
  internal BoltConfigAsset _config;

  [SerializeField]
  internal bool _ignore;

  /// <summary>
  /// The scene id of the map
  /// </summary>
  public int id {
    get { return _id; }
  }

  /// <summary>
  /// The scene path of the map
  /// </summary>
  public string path {
    get { return _scenePath; }
  }

  /// <summary>
  /// The user token assigned to this map
  /// </summary>
  public GameObject userToken {
    get { return _userToken; }
  }
}
