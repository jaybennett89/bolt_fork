﻿namespace UdpKit {
    public interface IUdpSequencedObject {
        uint Sequence { get; set; }
    }
}
