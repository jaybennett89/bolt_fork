﻿
namespace UdpKit {
    struct UdpHandle {
        public uint SendTime;
        public ushort ObjSequence;
        public bool IsObject;
        public object Object;
    }
}
