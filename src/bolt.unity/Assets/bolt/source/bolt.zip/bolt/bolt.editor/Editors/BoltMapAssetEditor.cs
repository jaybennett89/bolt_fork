﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(BoltMapAsset))]
public class BoltMapAssetEditor : Editor {
  public override void OnInspectorGUI () {
    BoltMapAsset asset = (BoltMapAsset) target;
    asset._ignore = EditorGUILayout.Toggle("Ignore", asset._ignore);
    asset._userToken = (GameObject) EditorGUILayout.ObjectField("User Token", asset._userToken, typeof(GameObject), false);
    asset._config = (BoltConfigAsset) EditorGUILayout.ObjectField("Configuration", asset._config, typeof(BoltConfigAsset), false);
  }
}
