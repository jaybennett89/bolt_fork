﻿using System;
using System.IO;
using UnityEditor;
using UnityEngine;

public static class BoltMenuItems {
  [MenuItem("Assets/Create/Bolt/Configuration")]
  public static void NewConfigAsset () {
    BoltEditorUtils.CreateAsset<BoltConfigAsset>("BoltConfig");
  }

  [MenuItem("Assets/Create/Bolt/State")]
  public static void NewStateAsset () {
    BoltEditorUtils.CreateAsset<BoltStateAsset>("BoltState");
  }

  [MenuItem("Assets/Create/Bolt/Event")]
  public static void NewEventAsset () {
    BoltEditorUtils.CreateAsset<BoltEventAsset>("BoltEvent");
  }

  [MenuItem("Assets/Create/Bolt/Command")]
  public static void NewCommandAsset () {
    BoltEditorUtils.CreateAsset<BoltCommandAsset>("BoltCommand");
  }

  [MenuItem("Assets/Create/Bolt/Mecanim")]
  public static void NewMecanimAsset () {
    BoltEditorUtils.CreateAsset<BoltMecanimAsset>("BoltMecanim");
  }

  [MenuItem("Assets/Create/Bolt/Map")]
  public static void NewMapAsset () {
    BoltEditorUtils.CreateAsset<BoltMapAsset>("BoltMap");
  }

  [MenuItem("Assets/Create/New Scriptable Object Asset")]
  public static void NewScriptableObjectAsset () {
    if (Selection.activeObject is MonoScript) {
      Type type = ((MonoScript) Selection.activeObject).GetClass();
      ScriptableObject obj = ScriptableObject.CreateInstance(type);

      string path = AssetDatabase.GetAssetPath(Selection.activeObject);
      path = Path.GetDirectoryName(path);
      path = path + "/" + type.Name + ".asset";
      path = AssetDatabase.GenerateUniqueAssetPath(path);

      AssetDatabase.CreateAsset(obj, path);

      Selection.activeObject = obj;
    } else {
      Debug.LogError(string.Format("Selected asset must be a MonoScript which contains a ScriptableObject class"));
    }

  }

  [MenuItem("Bolt/Compile")]
  public static void RunCompiler () {
    try {
      BoltUserAssemblyCompiler.Run();
    } catch {

    }
  }

  [MenuItem("Bolt/Install Gizmos")]
  public static void InstallGizmos () {
    BoltEditorUtils.InstallAsset("Assets/Gizmos/BoltEntity Icon.png", BoltEditorUtils.GetResourceBytes("bolt.editor.Resources.BoltEntity Icon.png"));
    BoltEditorUtils.InstallAsset("Assets/Gizmos/BoltEntity Gizmo.png", BoltEditorUtils.GetResourceBytes("bolt.editor.Resources.BoltEntity Gizmo.png"));
  }

  [MenuItem("Bolt/Install Mobile Free Support")]
  public static void InstallFreeSupport () {
    BoltEditorUtils.InstallAsset("Assets/Plugins/Android/libudpkit_android.so", BoltEditorUtils.GetResourceBytes("bolt.editor.Resources.libudpkit_android.so"));
    BoltEditorUtils.InstallAsset("Assets/Plugins/iOS/libudpkit_ios.a", BoltEditorUtils.GetResourceBytes("bolt.editor.Resources.libudpkit_ios.a"));
  }

  [MenuItem("Bolt/Install Tutorial Assets")]
  public static void InstallTutorialAssets () {
    try {
      Directory.CreateDirectory("Temp");
    } catch { }

    File.WriteAllBytes("Temp/TutorialAssets.unitypackage", BoltEditorUtils.GetResourceBytes("bolt.editor.Resources.TutorialAssets.unitypackage"));
    AssetDatabase.ImportPackage("Temp/TutorialAssets.unitypackage", false);
  }

  [MenuItem("Window/Bolt Connections")]
  public static void OpenInfoPanel () {
    BoltConnectionsWindow window = EditorWindow.GetWindow<BoltConnectionsWindow>();
    window.title = "Connections";
    window.name = "Connections";
    window.Show();
  }

  [MenuItem("Window/Bolt Map Launcher")]
  public static void OpenDebugStart () {
    BoltDebugStartWindow window = EditorWindow.GetWindow<BoltDebugStartWindow>();
    window.title = "Map Launcher";
    window.name = "Map Launcher";
    window.Show();
  }
}
