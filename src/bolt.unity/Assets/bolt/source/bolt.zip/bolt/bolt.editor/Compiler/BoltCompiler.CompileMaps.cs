﻿using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

partial class BoltCompiler {
  public static void CompileMaps (BoltCompilerOperation op) {
    for (int i = 0; i < op.maps.Count; ++i) {
      BoltMapAsset map = op.maps[i];

      if (map._ignore) {
        map._id = -1;
        EditorUtility.SetDirty(map);
        continue;
      }

      map._scenePath = AssetDatabase.GetAssetPath(map).Replace(".asset", ".unity");
      map._sceneName = Path.GetFileNameWithoutExtension(map._scenePath);
      map._id = ArrayUtility.FindIndex(EditorBuildSettings.scenes, s => map._scenePath == s.path);

      if (map._id == -1) {
        BoltLog.Warning("No scene found for map '{0}'", AssetDatabase.GetAssetPath(map));
      }

      EditorUtility.SetDirty(map);
    }

    // grab asset
    BoltRuntimeSettings table = BoltEditorUtils.GetSingletonAsset<BoltRuntimeSettings>();

    // update asset
    table._mapAssets = op.maps.Where(x => x._id >= 0).ToArray();

    // mark as dirty
    EditorUtility.SetDirty(table);

    using (BoltSourceFile file = new BoltSourceFile(op.mapsFilePath)) {
      file.EmitScope("public enum BoltMapNames : int", () => {
        for (int i = 0; i < op.maps.Count; ++i) {
          BoltMapAsset map = op.maps[i];

          if (map._id >= 0) {
            file.EmitLine("{0} = {1},", map.name.CSharpIdentifier(), map._id);
          }
        }
      });
    }
  }
}
